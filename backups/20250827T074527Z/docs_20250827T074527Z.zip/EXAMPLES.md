# PortPulse API 使用示例

> 推荐先导出两个变量（**注意用双引号**，使变量能展开）。

```bash
export BASE="https://api.useportpulse.com"
export API_KEY="dev_key_123"
