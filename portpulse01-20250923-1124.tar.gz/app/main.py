from __future__ import annotations

import os
import uuid
from http import HTTPStatus
from typing import Optional, Set

from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from starlette.middleware.base import BaseHTTPMiddleware

# --- Sentry（可选） ---
SENTRY_DSN = os.getenv("SENTRY_DSN")
if SENTRY_DSN:
    try:
        import sentry_sdk
        from sentry_sdk.integrations.fastapi import FastAPIIntegration
        sentry_sdk.init(dsn=SENTRY_DSN, traces_sample_rate=0.05, integrations=[FastAPIIntegration()])
    except Exception:
        pass

# --- 外部中间件（有则用，无则 None） ---
try:
    from app.middlewares.request_id import RequestIdMiddleware as ExternalRequestIdMw
except Exception:
    ExternalRequestIdMw = None

try:
    from app.middlewares.api_key import ApiKeyMiddleware as ExternalApiKeyMw
except Exception:
    ExternalApiKeyMw = None

from app.middlewares.rate_limit import RateLimitMiddleware
from app.openapi_extra import add_api_key_security

# ---------- 本地兜底中间件 ----------
class _LocalRequestIdMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        rid = request.headers.get("x-request-id") or str(uuid.uuid4())
        try:
            request.state.request_id = rid
        except Exception:
            pass
        response = await call_next(request)
        response.headers["x-request-id"] = rid
        return response

class _LocalApiKeyMiddleware(BaseHTTPMiddleware):
    def __init__(self, app, valid_keys: Set[str], demo_key: Optional[str]):
        super().__init__(app)
        self.valid = set(k for k in (valid_keys or set()) if k)
        self.demo = demo_key
        self._public_paths = {"/", "/v1/health", "/openapi.json", "/docs", "/redoc", "/robots.txt"}

    def _extract_key(self, request: Request) -> Optional[str]:
        key = request.headers.get("x-api-key")
        if not key:
            auth = request.headers.get("authorization", "")
            if auth.lower().startswith("bearer "):
                key = auth[7:].strip()
        return key

    async def dispatch(self, request: Request, call_next):
        if request.url.path in self._public_paths:
            return await call_next(request)
        key = self._extract_key(request)
        if key and self.demo and key == self.demo and request.method.upper() == "GET":
            return await call_next(request)
        if key and key in self.valid:
            return await call_next(request)
        rid = request.headers.get("x-request-id") or str(uuid.uuid4())
        return JSONResponse(
            status_code=401,
            headers={"x-request-id": rid},
            content={
                "code": "http_401",
                "message": "API key missing/invalid",
                "request_id": rid,
                "hint": "Provide API key via 'X-API-Key' or 'Authorization: Bearer <key>'",
            },
        )

# ---------- Health 硬旁路（应放在“最外层”，因此最后 add_middleware） ----------
class _HealthBypassMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        if request.url.path == "/v1/health":
            from datetime import datetime, timezone
            rid = request.headers.get("x-request-id") or str(uuid.uuid4())
            return JSONResponse(
                status_code=200,
                headers={"x-request-id": rid},
                content={"ok": True, "ts": datetime.now(timezone.utc).isoformat()},
            )
        return await call_next(request)

# ---------- Key 收集 ----------
def _collect_keys() -> tuple[Set[str], Optional[str]]:
    demo_key = os.getenv("NEXT_PUBLIC_DEMO_API_KEY", "dev_demo_123").strip()
    admin_key = os.getenv("ADMIN_API_KEY", "").strip()
    api_keys_env = os.getenv("API_KEYS", "")
    keys = set(k.strip() for k in api_keys_env.split(",") if k.strip())
    if admin_key:
        keys.add(admin_key)
    os.environ["NEXT_PUBLIC_DEMO_API_KEY"] = demo_key
    os.environ["API_KEYS"] = ",".join(sorted(keys))
    return keys, demo_key

# ---------- 应用工厂 ----------
def create_app() -> FastAPI:
    app = FastAPI(
        title="PortPulse API",
        version=os.getenv("APP_VERSION", "0.1.1"),
        docs_url="/docs",
        redoc_url="/redoc",
        openapi_url="/openapi.json",
        description=(
            "Authentication:\n"
            "  - Demo: header `X-API-Key: dev_demo_123`\n"
            "  - Production: `X-API-Key: <pp_xxx>` or `Authorization: Bearer <key>`\n"
        ),
    )

    # 先注册常规中间件（这些可能失败）
    if ExternalRequestIdMw:
        app.add_middleware(ExternalRequestIdMw)
    else:
        app.add_middleware(_LocalRequestIdMiddleware)

    valid_keys, demo_key = _collect_keys()
    if ExternalApiKeyMw:
        try:
            app.add_middleware(ExternalApiKeyMw)
        except Exception:
            app.add_middleware(_LocalApiKeyMiddleware, valid_keys=valid_keys, demo_key=demo_key)
    else:
        app.add_middleware(_LocalApiKeyMiddleware, valid_keys=valid_keys, demo_key=demo_key)

    # 可选限流（注意：后面我们还会把健康旁路加到“最外层”）
    if not os.getenv("DISABLE_RATELIMIT"):
        app.add_middleware(RateLimitMiddleware)

    # 路由
    from app.routers import meta, hs, alerts, ports, health  # noqa: E402
    app.include_router(meta.router)
    app.include_router(hs.router, prefix="/v1/hs", tags=["hs"])
    app.include_router(alerts.router, prefix="/v1", tags=["alerts"])
    app.include_router(ports.router, prefix="/v1/ports", tags=["ports"])
    app.include_router(health.router)  # /v1/health

    # 可选 trio
    try:
        from app.routers import ports_trio  # noqa: E402
        app.include_router(ports_trio.router, prefix="/v1/ports", tags=["ports"])
    except Exception:
        pass

    # Admin backfill（内部）
    try:
        from app.routers import admin_backfill  # noqa: E402
        app.include_router(admin_backfill.router, prefix="/v1/admin", tags=["admin"])
    except Exception:
        pass

    # /devportal 静态站（存在时挂载）
    try:
        if os.path.isdir("docs/devportal"):
            app.mount("/devportal", StaticFiles(directory="docs/devportal", html=True), name="devportal")
    except Exception:
        pass

    # 统一错误体
    def _request_id(req: Request) -> str:
        return req.headers.get("x-request-id") or str(uuid.uuid4())

    @app.exception_handler(HTTPException)
    async def _http_exc(request: Request, exc: HTTPException):
        rid = _request_id(request)
        return JSONResponse(
            status_code=exc.status_code,
            headers={"x-request-id": rid},
            content={
                "code": f"http_{exc.status_code}",
                "message": exc.detail or HTTPStatus(exc.status_code).phrase,
                "request_id": rid,
                "hint": None,
            },
        )

    @app.exception_handler(Exception)
    async def _any_exc(request: Request, exc: Exception):
        rid = _request_id(request)
        return JSONResponse(
            status_code=500,
            headers={"x-request-id": rid},
            content={"code": "http_500", "message": "Internal Server Error", "request_id": rid, "hint": None},
        )

    add_api_key_security(app)

    # **最后** 把健康旁路放到“最外层”，确保无条件 200
    app.add_middleware(_HealthBypassMiddleware)

    return app

app = create_app()

@app.get("/")
async def root():
    return RedirectResponse(url="/v1/health", status_code=307)
