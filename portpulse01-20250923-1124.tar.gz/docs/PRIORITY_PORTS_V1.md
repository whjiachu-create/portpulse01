# Priority Ports (v1)

**North America (14)**  
Los Angeles, Long Beach, New York–New Jersey, Savannah, Houston, Oakland, Seattle–Tacoma, Norfolk–Virginia, Charleston, Miami, Jacksonville, Baltimore, Vancouver (CA), Montreal (CA)

**Europe (14)**  
Rotterdam, Antwerp–Bruges, Hamburg, Felixstowe, Le Havre, Barcelona, Valencia, Algeciras, Gioia Tauro, Genoa, Piraeus, Gdansk, Zeebrugge, Bremerhaven

**Asia (17)**  
Singapore, Shanghai, Ningbo–Zhoushan, Shenzhen (Yantian/Shekou), Hong Kong, Qingdao, Tianjin, Xiamen, Kaohsiung, Busan, Tokyo/Yokohama, Kobe/Osaka, Laem Chabang, Tanjung Pelepas, Port Klang, Colombo, Nhava Sheva (JNPT)

**MEA/ANZ/LATAM (5)**  
Jebel Ali (Dubai), Durban, Cape Town, Santos (BR), Melbourne (AU)

**Growth rule**: every +10 ports requires a quick **MRR / marginal cost ×3** check.
