# Changelog

## 2025-08 — Public Beta (M1)
- Pricing/SLA/Errors docs and Postman collection.
- API key auth in OpenAPI; trend CSV ETag/304; smoke & quality scripts.
- Hourly ETL refresh; freshness monitor.

## 2025-08 — P1
- /v1/health, /v1/ports/* (trend/dwell/snapshot), docs site bootstrapped.
